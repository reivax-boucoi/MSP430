

void UART_transmit (unsigned char transmit_data);
void InitUART0 (void);
void UART0SendTxt(char* a);
