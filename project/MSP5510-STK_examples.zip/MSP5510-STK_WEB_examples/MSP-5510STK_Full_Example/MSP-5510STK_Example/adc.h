/**********************************************************************************/
/*    Test program for:															  */
/*	  Board: MSP430F5510-STK													  */
/*    Manufacture: OLIMEX                                                   	  */
/*	  COPYRIGHT (C) 2012														  */
/*    Designed by:  Georgi Todorov                                                */
/*    Module Name    :  GDSC-0801WP-01-MENT                                       */
/*    File   Name    :  adc.h                                                     */
/*    Revision       :  Rev.A                                                     */
/*    Date           :  20.01.2012					                              */
/**********************************************************************************/

#define   Num_of_Results   1

/****** 1.All functions prototypes *****/
void ADC_Init(void);

