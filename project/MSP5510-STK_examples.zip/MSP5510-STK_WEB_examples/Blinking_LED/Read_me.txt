Short description of MSP5510-STK_Blinking_LED demo program
	
The MSP5510-STK_Blinking_LED firmware blinks Green LED using Timer1 interrupt and the external 32768 crystal clock source
	
Pressing BUT 1 and BUT2 will change the blinking LED interval.

Note:

MSP5510-STK board has embedded USB HID bootloader and you can download the firmware using the Texas Instrumment tool(..MSP430 USB Firmware Upgrade Example\BSL_USB_GUI.exe without the need for JTAG device).

The output firmware file is generated in ..\MSP-5510STK_Full_Example\MSP-5510STK_Example\Debug\Exe directory. For MSP5510_STK_Full example project it is MSP-5510STK_Example.txt